<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MLM</title>
</head>

<body>
<div id="main" style="width:90%; height:725px; border:1px solid #CCC;">
  <div id="header" style="width:100%; height:70px; border:0px solid #000;">
    <div id="logo" style="width:49%; float:left; border:0px solid #000;"> 
    <img style="padding: 25px; width: 170px;" src="http://ovejobs.com/public/images/logo.jpg" /> </div>
    <div align="right" id="contact" style="width:49%; float:left; border:0px solid #000;">
      <p style="margin-top: 34px;">Email : <a style="color:#066;">infoMLM@gmail.com</a></p>
      <p>Contact No. : +91 9785834812</p>
    </div>
  </div>
  <div id="titllebar" style="height:80px; background-color:#00a651;">
    <p align="center" style="color: white;font-size: 34px; padding: 26px; font-variant: all-small-caps; font-family: monospace;">
    Forgot Login Details - Member</p>
  </div>
  <div id="dearname" style="width:100%;height:70px; padding: 11px;  padding-left: 35px; border:0px solid #000;">
    <p>Hello {templateName}</p>
    <p></p>
  </div>
  <div id="titllebar" style="height:50px;background-color: aliceblue;">
    <p style="color: #272020;font-size: 23px; padding: 13px;">Login Details</p>
  </div>
  <div>
    <p style="margin-left: 35px;"><strong>Email/Username :</strong> {templateEmail}</p>
    <p style="margin-left: 35px;"><strong>New Password :</strong> {templatePassword}</p>
    <br />
    <p style="margin-left: 35px;"> <a href="<?=base_url()?>">Click Here</a> 
    to Sign In to your Membership. If you cannot open link copy following link to the address bar of your
      
      browser: <a href="<?=base_url()?>">
      <?=base_url()?>
      </a> </p>
    <p style="margin-left: 35px;"> For any queries or assistance, mail to <a href="#">infoMLM@gmail.com</a> 
    or Call Us at: +91 9785834812 </p>
    <br />
    <p style="margin-left: 35px;">Best Regards</p>
    <p style="margin-left: 35px;">MLM</p>
  </div>
  <div id="titllebar" style="width:100%; height:50px;background-color: aliceblue;">
    <div style="width:50%; float:left; color: #272020;font-size: 23px; margin-top: 12px; padding-left: 11px;">
    MLM Pvt. Ltd.</div>
    <div style="width:48%; float:left; margin-top: 20px; " align="right"> <a href="<?=base_url()?>">
      <?=base_url()?>
      </a> </div>
  </div>
</div>
</body>
</html>
